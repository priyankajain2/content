package com.cg.adb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.adb.exception.AdbException;
import com.cg.adb.model.ContactModel;
import com.cg.adb.service.ContactService;

@RestController
@RequestMapping("/contact")
@CrossOrigin
public class ContactController {

	private ContactService contactService;
	
	public ContactService getContactService() {
		return contactService;
	}

	@Autowired
	public void setContactService(ContactService contactService) {
		this.contactService = contactService;
	}

	@GetMapping
	public ResponseEntity<List<ContactModel>> getAllContacts() {
		return new ResponseEntity<List<ContactModel>>(contactService.findAll(), HttpStatus.OK);
	}

	@GetMapping("/{contactId}")
	public ResponseEntity<ContactModel> getGroupById(@PathVariable("contactId") Long contactId) {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.findById(contactId);

		if (null == model) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(model, HttpStatus.OK);
		}

		return result;
	}

	@PostMapping
	public ResponseEntity<ContactModel> addGroup(@RequestBody ContactModel contact) throws AdbException {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.add(contact);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@PutMapping
	public ResponseEntity<ContactModel> saveGroup(@RequestBody ContactModel contact) throws AdbException {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.save(contact);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@DeleteMapping("/{groupId}")
	public ResponseEntity<Void> deleteGroupById(@PathVariable("contactId") Long contactId) throws AdbException {
		contactService.delete(contactId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@ExceptionHandler(AdbException.class)
	public ResponseEntity<String> handleAdbException(AdbException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
