package com.cg.adb.model;

import java.io.Serializable;

import com.cg.adb.entity.GroupEntity;

public class GroupModel implements Serializable{

	private static final long serialVersionUID = 3070965313561168466L;
	
	private Long groupId;
	private String groupName;
	private String description;
	
	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
