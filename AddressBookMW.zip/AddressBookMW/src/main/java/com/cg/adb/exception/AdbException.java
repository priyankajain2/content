package com.cg.adb.exception;

public class AdbException extends Exception {

	public AdbException(String msg) {
		super(msg);
	}
}
