package com.cg.adb.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.cg.adb.model.ContactModel;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="contacts")
public class ContactEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "CID_SEQ_GEN")
	@SequenceGenerator(name= "CID_SEQ_GEN",sequenceName = "SEQ_CID",initialValue = 1,allocationSize = 1)
	private Long contactId;
	
	@Column(name="fnm",nullable = false)
	private String firstName;
	
	@Column(name="mnm",nullable = false)
	private String middleName;
	
	@Column(name="lnm",nullable = false)
	private String lastName;
	
	@Enumerated(EnumType.STRING)
	@Column(name="gdr",nullable = false)
	private Gender gender;
	
	@Column(name="dob",nullable = false)
	private LocalDate dateOfBirth;
	
	@Column(name="mno",nullable = false,unique = true)
	private String mobileNumber;
	
	@Column(name="mid",nullable = false,unique = true)
	private String mailId;
	
	@Column(name="wnm",nullable = true,unique = true)
	private String whatsAppNumber;
	
	@Column(name="fid",nullable = true,unique = true)
	private String faceBookId;
	
	@ManyToOne
	@JoinColumn(name="grpId")
	private GroupEntity group;

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getWhatsAppNumber() {
		return whatsAppNumber;
	}

	public void setWhatsAppNumber(String whatsAppNumber) {
		this.whatsAppNumber = whatsAppNumber;
	}

	public String getFaceBookId() {
		return faceBookId;
	}

	public void setFaceBookId(String faceBookId) {
		this.faceBookId = faceBookId;
	}

	public GroupEntity getGroup() {
		return group;
	}

	public void setGroup(GroupEntity group) {
		this.group = group;
	}

}
