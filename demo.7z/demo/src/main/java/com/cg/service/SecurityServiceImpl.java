package com.cg.service;

import org.springframework.stereotype.Service;

import com.cg.model.AppUser;

@Service
public class SecurityServiceImpl implements SecurityService {

	@Override
	public boolean verifyUser(AppUser appUser) {
		boolean authorized=false;
		if(appUser.getUserName().equals("admin")) {
			if(appUser.getPassword().equals("admin")) {
				authorized=true;
			}
		}
		
		return authorized;
	}
}
