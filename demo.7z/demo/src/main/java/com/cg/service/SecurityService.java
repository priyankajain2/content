package com.cg.service;

import com.cg.model.AppUser;

public interface SecurityService {

	boolean verifyUser(AppUser appUser);

}