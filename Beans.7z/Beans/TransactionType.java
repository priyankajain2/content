package com.cg.accountmanagement.bean;

public enum TransactionType {
	CREDIT, DEBIT;
}
