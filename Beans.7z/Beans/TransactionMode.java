package com.cg.accountmanagement.bean;

public enum TransactionMode {
	ONLINE, CASH;
}
