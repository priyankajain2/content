package com.cg.accountmanagement.bean;

public enum AccountStatus {
	ACTIVE, CLOSED;
}
