package com.cg.accountmanagement.bean;

public enum AccountType {
	SAVINGS, FIXED_DEPOSIT, RECURRING_DEPOSIT;
}
