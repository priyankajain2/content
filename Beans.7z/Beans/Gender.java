package com.cg.accountmanagement.bean;

public enum Gender {
	PREFER_NOT_TO_SAY, MALE, FEMALE;
}
