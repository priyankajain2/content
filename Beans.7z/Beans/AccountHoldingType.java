package com.cg.accountmanagement.bean;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL;
}
