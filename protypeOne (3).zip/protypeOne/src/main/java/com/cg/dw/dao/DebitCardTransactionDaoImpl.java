package com.cg.dw.dao;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.DebitCardTransaction;

@Repository
public class DebitCardTransactionDaoImpl implements DebitCardTransactionDao {
	//private static Logger logger = Logger.getLogger(DebitCardTransactionDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	

	@Override
	public boolean verifyDebitTransactionId(BigInteger transactionId) throws IBSException {
		//logger.info("entered into verifyDebitTransactionId method of DebitCardTransactionDaoImpl class");
		boolean result = false;

		DebitCardTransaction d = entityManager.find(DebitCardTransaction.class, transactionId);

		if (d != null) {
			result = true;
		}

		return result;

	}

	@Override
	public List<DebitCardTransaction> getDebitTrans(LocalDate startDate , LocalDate endDate, BigInteger debitCardNumber) throws IBSException {
		//logger.info("entered into getDebitTrans method of DebitCardTransactionDaoImpl class");
		
        LocalDateTime startDate1 = startDate.atTime(LocalTime.now());
        LocalDateTime endDate1 = endDate.atTime(LocalTime.now());
        List<DebitCardTransaction> debitCards = null;
        try {
            TypedQuery<DebitCardTransaction> query = entityManager.createQuery(
                    "Select d from DebitCardTransaction d JOIN d.debitBeanObject c WHERE d.transactionDate BETWEEN :start and :end AND c.cardNumber=:cardNum ",
                    DebitCardTransaction.class);
            query.setParameter("start", startDate1);
            query.setParameter("end", endDate1);
            query.setParameter("cardNum", debitCardNumber);
            debitCards = query.getResultList();
        } catch (NoResultException e) {
            throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
        }
        return debitCards;
  
  
	}

	@Override
	public BigInteger getDMUci(BigInteger transactionID) throws IBSException {
		//logger.info("entered into getDMUci method of DebitCardTransactionDaoImpl class");
		BigInteger uci = null;

		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select d.UCI from DebitCardTransaction d where d.transactionId=:transactionId", BigInteger.class);
			query.setParameter("transactionId", transactionID);
			uci = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.NO_UCI);
		}
		return uci;

	}

	@Override
	public BigInteger getDebitCardNumber(BigInteger transactionID) throws IBSException {
		//logger.info("entered into getDebitCardNumber method of DebitCardTransactionDaoImpl class");
		BigInteger cardNumber = null;
		try {
			TypedQuery<BigInteger> query = entityManager.createQuery(
					"Select c.cardNumber from DebitCardTransaction d  join d.debitBeanObject c where d.transactionId=:transactionId",
					BigInteger.class);
			query.setParameter("transactionId", transactionID);

			cardNumber = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return cardNumber;

	}

	@Override
	public BigInteger getDebitMismatchTranscId(String queryId) throws IBSException {
		
		BigInteger transcId = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"Select d.defineServiceRequest from CaseIdBean d  WHERE d.caseIdTotal =:QueryId ", String.class);
			query.setParameter("QueryId", queryId);

			transcId = new BigInteger(query.getSingleResult());
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.TRANS_NOT_EXIST_MESSAGE);
		}
		return transcId;

	}

	@Override
	public DebitCardTransaction getDebitMismatchTransc(BigInteger mismatchTransactionId) throws IBSException {

	DebitCardTransaction debitCardList;
		try {
		/*	TypedQuery<DebitCardTransaction> query = entityManager.createQuery(
					"Select d from DebitCardTransaction d WHERE d.transactionId =:TransactionId ",
					DebitCardTransaction.class);*/
		
			debitCardList =entityManager.find(DebitCardTransaction.class, mismatchTransactionId);

		} catch (NullPointerException e) {

			throw new IBSException(ErrorMessages.TRANSACTION_ID_NOT_EXIST_MESSAGE);
		}
		return debitCardList;
	}

	@Override
	public boolean checkTransactions(BigInteger debitCardNumber) throws IBSException {
		boolean result = false;
		
		try {
            TypedQuery<DebitCardTransaction> query = entityManager.createQuery(
                    "Select d from DebitCardTransaction d JOIN d.debitBeanObject c WHERE c.cardNumber=:cardNum ",
                    DebitCardTransaction.class);
    
            query.setParameter("cardNum", debitCardNumber);
           List<DebitCardTransaction> debitCards = query.getResultList();
           if (debitCards.size()>0) {
        	   result = true;
           }
        } catch (NoResultException e) {
            throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
        }
		
		
		
        return result;
  
	}

}
