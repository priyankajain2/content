package com.cg.dw.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.CaseIdDao;
import com.cg.dw.dao.CustomerDao;
import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;

@Service
public class CustomerServiceImpl implements CustomerService {
	//private static Logger logger = Logger.getLogger(CustomerServiceImpl.class);
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired
	private CustomerDao customerDao;

	public void getCardLength(BigInteger card) throws IBSException {

		if (card.toString().length() != 16)
			throw new IBSException(ErrorMessages.INC_LENGTH_PIN_MESSAGE);

	}

	Random random = new Random();

	String setCardType = null;

	public String getNewCardtype(int newCardType) throws IBSException {

		//logger.info("entered into getNewCardType method of CustomerServiceImpl class");
		String cardType = newCardType + "";
		Pattern pattern = Pattern.compile("[123]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_INPUT_MESSAGE);

		switch (newCardType) {
		case 1:

			setCardType = "Platinum";
			break;
		case 2:
			setCardType = "Gold";
			break;
		case 3:
			setCardType = "Silver";
			break;

		}
		return setCardType;
	}

	@Override
	public boolean getPinLength(String pin) throws IBSException {
		boolean check = false;
		//logger.info("entered into getPinLength method of CustomerServiceImpl class");

		int count = pin.length();

		if (count == 4)
			check = true;

		return check;
	}

	@Override
    public List<CaseIdBean> listAllQueries(BigInteger uci) throws IBSException {
        List<CaseIdBean> list=null;
        try {
            list= caseIdDao.viewAllServiceRequests();
        } catch (IBSException e) {
            throw new IBSException(e.getMessage());
        }
         return list;
   
    }
	@Override
	public String viewServiceRequestStatus(String customerReferenceId) throws IBSException {
		//logger.info("entered into viewServiceRequestStatus method of CustomerServiceImpl class");
		CaseIdBean caseIdObj = new CaseIdBean();
		caseIdObj.setCustomerReferenceId(customerReferenceId);

		String currentServiceRequestStatus = caseIdDao.getCustomerReferenceStatus(caseIdObj, customerReferenceId);
		if (currentServiceRequestStatus == null)
			throw new IBSException(ErrorMessages.INVALID_TRANSACTION_ID_MESSAGE);

		return currentServiceRequestStatus;

	}

	@Override
	public String checkMyChoice(int myChoice) throws IBSException {
	//	logger.info("entered into checkMyChoice method of CustomerServiceImpl class");
		String cardType = myChoice + "";
		Pattern pattern = Pattern.compile("[12]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_CHOICE_MESSAGE);

		switch (myChoice) {
		case 1:
			setCardType = "Gold";
			break;
		case 2:
			setCardType = "Platinum";
			break;

		}
		return setCardType;

	}

	@Override
	public String checkMyChoiceGold(int myChoice) throws IBSException {
		String cardType = myChoice + "";
		Pattern pattern = Pattern.compile("[2]");
		Matcher matcher = pattern.matcher(cardType);
		if (!(matcher.find() && matcher.group().equals(cardType)))
			throw new IBSException(ErrorMessages.INVALID_CHOICE_MESSAGE);
		return ("Platinum");
	}

	@Override
	public void checkDays(int days1) throws IBSException {
		//logger.info("entered into checkDays method of CustomerServiceImpl class");
		if (days1 < 1) {

			throw new IBSException(ErrorMessages.LESS_DAYS_MESSAGE);

		} else if (days1 >= 730) {

			throw new IBSException(ErrorMessages.MORE_DAYS_MESSAGE);
		}

	}

	@Override
	public boolean verifyUci(BigInteger uci) throws IBSException {
		String suci = uci.toString();
		Pattern pattern = Pattern.compile("[0-9]{16}");
		Matcher matcher = pattern.matcher(suci);
		if (!(matcher.find() && matcher.group().equals(suci)))
			throw new IBSException(ErrorMessages.INC_LENGTH_UCI_MESSAGE);
		boolean check1 = customerDao.verifyUCI(uci);
		if (!check1)
			throw new IBSException(ErrorMessages.CRED_CARD_NOT_EXIST_MESSAGE);
		return (check1);
	}

}