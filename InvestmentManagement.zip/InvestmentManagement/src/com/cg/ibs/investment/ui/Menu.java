package com.cg.ibs.investment.ui;

public enum Menu {
	VIEW_MY_INVESTMENT,viewGoldPrice,viewSilverPrice,viewMFplans,buyGold,sellGold,buySilver,sellSilver,depositMFplan,WithdrawMFplan,Quit

}
