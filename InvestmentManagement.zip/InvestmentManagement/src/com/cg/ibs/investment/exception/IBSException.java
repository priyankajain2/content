package com.cg.ibs.investment.exception;

public class IBSException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public IBSException(String message){
		super(message);
		
	}
	}
