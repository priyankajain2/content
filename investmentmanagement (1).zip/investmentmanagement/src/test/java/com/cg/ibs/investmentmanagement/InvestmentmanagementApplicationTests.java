package com.cg.ibs.investmentmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestmentmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
