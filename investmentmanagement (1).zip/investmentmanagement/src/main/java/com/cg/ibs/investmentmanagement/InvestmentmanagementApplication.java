package com.cg.ibs.investmentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestmentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvestmentmanagementApplication.class, args);
	}

}
