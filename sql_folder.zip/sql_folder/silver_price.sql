create table silver_price(update_date DATE PRIMARY KEY,silver_price number(10,2) NOT NULL);

insert into silver_price values('2019-10-14',2800.25);

insert into silver_price values('2019-10-15',2950.00);