create table gold_price(update_date DATE PRIMARY KEY,gold_price number(10,2) NOT NULL);

insert into gold_price values('2019-10-15',40000.00);

insert into gold_price values('2019-10-16',38000.00);
