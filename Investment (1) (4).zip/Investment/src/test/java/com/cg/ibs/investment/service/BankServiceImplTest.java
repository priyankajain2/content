package com.cg.ibs.investment.service;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import javax.persistence.EntityTransaction;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import com.cg.ibs.investment.bean.BankMutualFund;
import com.cg.ibs.investment.dao.BankMutualFundDao;
import com.cg.ibs.investment.dao.BankMutualFundDaoImpl;
import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.util.JPAUtil;

class BankServiceImplTest {
	private BankServiceImpl bank;

	@BeforeEach
	void setUp() {
		bank = new BankServiceImpl();
	}

	@Test
	void testIsValidGoldSilverPositive() {
		assertEquals(true, bank.isValidGoldSilver(10.00));
	}

	@Test
	void testisvalidgoldSilverNegative() {
		assertNotEquals(true, bank.isValidGoldSilver(-10));
	}

	@Test
	void testUpdateGoldPrice() {
		CustomerService customerService = new CustomerServiceImpl();
		try {
			bank.updateGoldPrice(new Double(2600));
			Double updatedgp = customerService.viewGoldPrice();
			assertAll(() -> assertNotEquals(updatedgp, 2600), () -> assertThrows(IBSException.class, () -> {
				bank.updateGoldPrice(new Double(-100));
			}));

		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

	@Test
	void testUpdateSilverPrice() {
		CustomerService customerService = new CustomerServiceImpl();
		try {
			bank.updateSilverPrice(new Double(260));
			Double updatedsp = customerService.viewSilverPrice();
			assertAll(() -> assertNotEquals(updatedsp, 260), () -> assertThrows(IBSException.class, () -> {
				bank.updateSilverPrice(new Double(-100));
			}));

		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

	@Disabled
	@Test
	void testaddMf() {
		try {
			CustomerService customerService = new CustomerServiceImpl();
			BankMutualFundDao dao = new BankMutualFundDaoImpl();
			BankMutualFund mf = new BankMutualFund();
			mf.setMfPlanId(10009);
			mf.setNav(new Double(300));
			mf.setTitle("IBS_FAMILY");
			EntityTransaction txn = JPAUtil.getTransaction();
			txn.begin();
			dao.addBankMutFund(mf);
			txn.commit();
			assertNotNull(customerService.viewMFPlans().get(10009));
		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

	@Test
	void testupdateNav() {
		try {
			CustomerService customerService = new CustomerServiceImpl();
			BankMutualFundDao dao = new BankMutualFundDaoImpl();
			BankMutualFund fund = dao.getMfById(10002);
			fund.setNav(new Double(450));
			assertEquals(new Double(450), customerService.viewMFPlans().get(10002).getNav());
		} catch (IBSException e) {
			assertNotNull(e);
		}
	}

}