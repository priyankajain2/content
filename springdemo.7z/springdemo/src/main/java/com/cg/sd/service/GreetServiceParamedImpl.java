package com.cg.sd.service;

public class GreetServiceParamedImpl implements GreetService {

	private String greetNote;
	
	@Override
	public String greet(String userName) {
		return greetNote + userName;
	}

	public String getGreetNote() {
		return greetNote;
	}

	public void setGreetNote(String greetNote) {
		this.greetNote = greetNote;
	}

	
}
