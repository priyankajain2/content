package com.cg.ibs.investment.ui;

import java.time.LocalDate;

import com.cg.ibs.investment.exception.IBSException;
import com.cg.ibs.investment.service.CustomerService;
import com.cg.ibs.investment.service.CustomerServiceImpl;

public class Test {
	
	public static void main(String[] args) {
		CustomerService cs=new CustomerServiceImpl();
		try {
			cs.autoSip("user1");
			System.err.println("dfksd");
		} catch (IBSException e) {
			e.printStackTrace();
		}
		
	}

}
