package com.cg.ibs.investment.bean;

public enum AccountType {
	LOAN,SAVINGS,INVESTMENT
}
